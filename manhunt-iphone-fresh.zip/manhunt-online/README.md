# MANHUNT Online
A real-life outdoor Manhunt companion for 2-10 friends. No GPS or location collection.

## Run locally
1. Install Node.js 18+.
2. Run `npm install` in this folder.
3. Run `npm start`.
4. Open http://localhost:3000.

## Publish on Render
1. Upload this project to a GitHub repository (keep `server.js`, `package.json`, and `public/`).
2. On render.com choose **New > Web Service**, connect your GitHub repository.
3. Select **Node**, build command `npm install`, start command `npm start`.
4. Deploy, then share your Render website URL. Each player opens the website and joins using a private room code.

## Notes
- Game rooms live in server memory and reset when the server restarts or sleeps.
- Use one server instance; multiple instances need a shared room store and Socket.IO adapter.
- No login, GPS, map, or public lobby. Room codes are not passwords: share only with trusted friends.
- For a production public service, add rate limiting, abuse prevention, persistent storage, moderation, and robust session handling.
