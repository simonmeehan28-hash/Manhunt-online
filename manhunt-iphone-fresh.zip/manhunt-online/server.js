const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const app = express();
app.use(express.static(path.join(__dirname, 'public')));
const server = http.createServer(app);
const io = new Server(server);
const rooms = new Map();
const clean = (v, max=30) => String(v || '').trim().slice(0,max).replace(/[<>]/g,'');
const now = () => Date.now();
function code(){let c;do{c=String(Math.floor(100000+Math.random()*900000));}while(rooms.has(c));return c;}
function publicRoom(r){return {code:r.code,host:r.host,phase:r.phase,roundEnd:r.roundEnd,hideEnd:r.hideEnd,hideSeconds:r.hideSeconds,roundSeconds:r.roundSeconds,boundary:r.boundary,players:[...r.players.values()].map(p=>({id:p.id,name:p.name,role:p.role,caught:p.caught,connected:p.connected})),pending:r.pending};}
function emit(r){io.to(r.code).emit('state',publicRoom(r));}
function stop(r){r.phase='finished';r.roundEnd=null;r.hideEnd=null;r.pending=null;emit(r);}
function update(r){if(r.phase==='hiding' && now()>=r.hideEnd){r.phase='hunting';r.hideEnd=null;}if(r.phase==='hunting' && now()>=r.roundEnd){stop(r);return;}if(r.phase==='hunting' && [...r.players.values()].filter(p=>p.role==='hider').every(p=>p.caught)){stop(r);return;}emit(r);}
function callback(cb,data){if(typeof cb==='function')cb(data);}
io.on('connection',socket=>{
 socket.on('join',({roomCode,name,token}={},cb)=>{
  name=clean(name,20);if(!name)return callback(cb,{error:'Enter a nickname.'});
  let r;if(roomCode){r=rooms.get(clean(roomCode,6));if(!r)return callback(cb,{error:'Room not found.'});}else{const c=code();r={code:c,host:null,phase:'lobby',roundEnd:null,hideEnd:null,hideSeconds:60,roundSeconds:600,boundary:'',players:new Map(),pending:null};rooms.set(c,r);}
  let p=token?[...r.players.values()].find(x=>x.token===token):null;
  if(!p){if(r.phase!=='lobby')return callback(cb,{error:'Game already started.'});if(r.players.size>=10)return callback(cb,{error:'Room is full (10 players).'});p={id:require('crypto').randomUUID(),token:require('crypto').randomBytes(24).toString('hex'),name,role:'hider',caught:false,connected:true};r.players.set(p.id,p);if(!r.host)r.host=p.id;}
  if(p.socketId){const old=io.sockets.sockets.get(p.socketId);if(old){old.leave(r.code);old.data.room=null;}}
  p.socketId=socket.id;p.connected=true;socket.join(r.code);socket.data={room:r.code,player:p.id};callback(cb,{ok:true,token:p.token,id:p.id,code:r.code});emit(r);
 });
 socket.on('action',({type,value,target}={},cb)=>{
  const r=rooms.get(socket.data.room);const p=r?.players.get(socket.data.player);if(!r||!p||p.socketId!==socket.id)return callback(cb,{error:'Rejoin the game.'});
  const host=p.id===r.host;const fail=msg=>callback(cb,{error:msg});
  if(type==='settings') {if(!host||r.phase!=='lobby')return fail('Only the host can edit settings.');r.hideSeconds=Math.min(300,Math.max(15,Number(value?.hide)||60));r.roundSeconds=Math.min(3600,Math.max(60,Number(value?.round)||600));r.boundary=clean(value?.boundary,180);}
  else if(type==='role'){if(!host||r.phase!=='lobby')return fail('Only the host can set roles.');const t=r.players.get(target);if(!t)return fail('Player not found.');t.role=t.role==='hunter'?'hider':'hunter';}
  else if(type==='start'){if(!host||r.phase!=='lobby')return fail('Only the host can start.');if(r.players.size<2)return fail('At least two players required.');const ps=[...r.players.values()];if(!ps.some(x=>x.role==='hunter')||!ps.some(x=>x.role==='hider'))return fail('Choose at least one hunter and one hider.');if(!r.boundary.trim())return fail('Enter safe play boundaries before starting.');ps.forEach(x=>x.caught=false);r.phase='hiding';r.hideEnd=now()+r.hideSeconds*1000;r.roundEnd=r.hideEnd+r.roundSeconds*1000;}
  else if(type==='requestTag'){if(r.phase!=='hunting'||p.role!=='hunter'||r.pending)return fail('Tag unavailable.');const t=r.players.get(target);if(!t||t.role!=='hider'||t.caught)return fail('Choose an active hider.');r.pending={hunter:p.id,hider:t.id};}
  else if(type==='confirmTag'){if(!r.pending||r.pending.hider!==p.id)return fail('No tag awaiting your confirmation.');if(value==='yes')r.players.get(p.id).caught=true;r.pending=null;}
  else if(type==='cancelTag'){if(!r.pending||(!host&&r.pending.hunter!==p.id))return fail('Cannot cancel.');r.pending=null;}
  else if(type==='end'){if(!host)return fail('Only the host can end.');stop(r);}
  else if(type==='reset'){if(!host||r.phase!=='finished')return fail('Only the host can reset.');r.phase='lobby';r.pending=null;r.players.forEach(x=>x.caught=false);}
  else return fail('Unknown action.');
  callback(cb,{ok:true});update(r);
 });
 socket.on('disconnect',()=>{const r=rooms.get(socket.data.room);const p=r?.players.get(socket.data.player);if(p&&p.socketId===socket.id){p.connected=false;if(r.phase==='lobby'){r.players.delete(p.id);if(r.host===p.id)r.host=r.players.keys().next().value||null;}if(!r.players.size){rooms.delete(r.code);}else emit(r);}});
});
setInterval(()=>{for(const r of rooms.values())if(r.phase==='hiding'||r.phase==='hunting')update(r);},1000);
server.listen(process.env.PORT||3000,()=>console.log('Manhunt running'));
